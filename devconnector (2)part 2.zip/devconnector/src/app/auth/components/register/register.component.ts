import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Register } from '../../models/register';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  register: Register = new Register();
  //object for holding the registration details.
  error: any = {};
  // used to hold error obejct details
  constructor(private router: Router, private authService: AuthService) {}

  ngOnInit(): void {}
  registerSubmit() {
    console.log(JSON.stringify(this.register));
    console.log('hello from shree');

    this.authService.registerUser(this.register).subscribe(
      (res) => {
        console.log(JSON.stringify(res));
        this.router.navigate(['/auth/login']);
      },
      (err) => {
        this.error = err.error;
        console.log(JSON.stringify(err.error));
      }
    );
  }
}
