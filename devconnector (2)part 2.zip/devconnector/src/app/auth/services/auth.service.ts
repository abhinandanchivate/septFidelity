import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Register } from '../models/register';

const headeroptions = {
  headers: new HttpHeaders({
    'content-Type': 'application/json',
  }),
};
@Injectable({
  providedIn: 'root',
})
export class AuthService {
  api = '/api/users/';
  constructor(private httpClient: HttpClient) {}

  registerUser(data): Observable<any> {
    return this.httpClient.post<Register>(
      this.api + 'register',
      data,
      headeroptions
    );
  }
}
