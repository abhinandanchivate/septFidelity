import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Register } from '../../models/register';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  register: Register = new Register();
  //object for holding the registration details.

  constructor(private router: Router) {}

  ngOnInit(): void {}
  registerSubmit() {
    console.log(JSON.stringify(this.register));
    console.log('hello from shree');
    this.router.navigate(['/auth/login']);
  }
}
